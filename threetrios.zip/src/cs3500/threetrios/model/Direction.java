package cs3500.threetrios.model;

/**
 * Represents the direction of the attack.
 */
public enum Direction {
  NORTH, SOUTH, EAST, WEST
}
